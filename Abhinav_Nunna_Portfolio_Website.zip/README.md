# Abhinav Nunna — Personal Portfolio

A responsive, single-page portfolio website built with plain HTML, CSS and JavaScript.

## Preview locally
Open `index.html` in any modern browser.

## Publish free
1. Create a GitHub repository named `Abhinav6849.github.io` (or another repository).
2. Upload `index.html` and `Abhinav_Resume.pdf`.
3. For a user-site repository named `Abhinav6849.github.io`, enable GitHub Pages in Settings → Pages and choose the main branch.
4. Your site will be available at `https://abhinav6849.github.io/` after publishing finishes.

## Personalization notes
- Replace or update the résumé PDF whenever needed (the button downloads `Abhinav_Resume.pdf`).
- Confirm the Naukri profile URL and replace the generic Naukri link in `index.html` with the direct profile URL.
- The site intentionally does not list work experience or projects because the supplied résumé did not include verified details for them.
