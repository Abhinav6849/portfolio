import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Minus, c as Mail, d as Check, f as ArrowUpRight, i as Phone, l as Download, o as Menu, r as Plus, s as MapPin, t as X, u as Copy } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D1bVj6Ak.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var profile = {
	name: "Abhinav Nunna",
	first: "Abhinav",
	last: "Nunna",
	role: "Java Full Stack Developer",
	availability: "Fresher · open to roles",
	place: "Uyyalawada, Mahabubabad",
	region: "Telangana 506381",
	email: "abhinavnunna0907@gmail.com",
	phoneDisplay: "+91 91103 22065",
	phoneTel: "+919110322065",
	github: "https://github.com/Abhinav6849",
	githubHandle: "Abhinav6849",
	linkedin: "https://www.linkedin.com/in/nunna-abhinav-8572463a8",
	resume: "/Abhinav-Nunna-CV.pdf",
	portrait: "/portrait.jpg",
	summary: "Aspiring Java full-stack developer with a solid grounding in Core Java, Spring Boot, and modern web work. I like reliable, scalable applications — and I want to grow by solving real problems with a team."
};
var lenses = [
	{
		id: "all",
		label: "Whole profile",
		hint: "Everything on the résumé, unfiltered."
	},
	{
		id: "backend",
		label: "Backend",
		hint: "Java, Spring, Hibernate, and data stores."
	},
	{
		id: "fullstack",
		label: "Full stack",
		hint: "An API plus a screen someone can use."
	},
	{
		id: "frontend",
		label: "Frontend",
		hint: "HTML, CSS, JavaScript — React is still early."
	}
];
var skillGroups = [
	{
		id: "backend",
		label: "Backend",
		lenses: ["backend", "fullstack"],
		items: [
			{ name: "Core Java" },
			{ name: "J2EE" },
			{ name: "Spring Framework" },
			{ name: "Spring Boot" },
			{ name: "Hibernate" },
			{ name: "RESTful services" }
		]
	},
	{
		id: "frontend",
		label: "Frontend",
		lenses: ["frontend", "fullstack"],
		items: [
			{ name: "HTML5" },
			{ name: "CSS3" },
			{ name: "JavaScript" },
			{ name: "Bootstrap" },
			{
				name: "React",
				note: "Beginner"
			}
		]
	},
	{
		id: "data",
		label: "Databases",
		lenses: [
			"backend",
			"fullstack",
			"frontend"
		],
		items: [{ name: "MySQL" }, { name: "PostgreSQL" }]
	},
	{
		id: "tools",
		label: "Tools",
		lenses: [
			"backend",
			"fullstack",
			"frontend"
		],
		items: [
			{ name: "Git" },
			{ name: "GitHub" },
			{ name: "Maven" },
			{ name: "Eclipse" },
			{ name: "IntelliJ IDEA" },
			{ name: "Postman" }
		]
	},
	{
		id: "concepts",
		label: "Core concepts",
		lenses: [
			"backend",
			"fullstack",
			"frontend"
		],
		items: [
			{ name: "Object-oriented programming" },
			{ name: "Data structures & algorithms" },
			{ name: "MVC" },
			{ name: "Software development life cycle" }
		]
	}
];
var projects = [{
	index: "01",
	name: "Online Job Portal",
	aka: "Records, courses, attendance",
	status: "In progress",
	sketch: "portal",
	lenses: ["backend", "fullstack"],
	stack: [
		"Java",
		"Spring Boot",
		"MySQL",
		"HTML",
		"CSS"
	],
	flow: [
		"HTML & CSS",
		"Spring Boot REST",
		"MySQL"
	],
	summary: "A Spring Boot application for managing student records, course details, and attendance. The useful core is a REST API with full create, read, update, and delete.",
	points: [
		"Designed the web flow for records a college admin actually keeps: students, courses, attendance.",
		"REST endpoints cover the full CRUD cycle so data operations stay straightforward.",
		"MySQL holds the data, with queries tuned so the system stays responsive."
	],
	note: "Sits beside the Spring Boot & Microservices certification, also in progress."
}, {
	index: "02",
	name: "MegaBazar",
	aka: "E-commerce web application",
	status: "In progress",
	sketch: "bazaar",
	lenses: [
		"backend",
		"fullstack",
		"frontend"
	],
	stack: [
		"Java",
		"Spring",
		"Hibernate",
		"React",
		"MySQL"
	],
	flow: [
		"React",
		"Spring + Hibernate",
		"MySQL"
	],
	summary: "An end-to-end shop: registration, login, a product catalogue, a cart, and order placement. Spring and Hibernate serve the API; React renders the store.",
	points: [
		"Secure registration and login before a shopper can move through the store.",
		"Catalogue, cart, and orders share one backend instead of living as separate prototypes.",
		"React components call the Spring APIs. The Java side is where I’m strongest — React is marked beginner on purpose."
	],
	note: "The project I use to practice connecting a real UI to a Java API."
}];
var education = [
	{
		years: "2025",
		title: "Bachelor of Technology — Computer Science & Engineering",
		place: "ISBM University",
		detail: "Aggregate 68%"
	},
	{
		years: "2021",
		title: "Intermediate (Class XII)",
		place: "Sri Chaitanya College",
		detail: "Score 516"
	},
	{
		years: "2019",
		title: "Secondary School Certificate (Class X)",
		place: "Ekashila E Techno School",
		detail: "CGPA 8.7"
	}
];
var courses$1 = [{
	title: "Java Full Stack Development",
	place: "360 DigiRI",
	status: "In progress"
}, {
	title: "Spring Boot & Microservices",
	place: "Online Job Portal project certification",
	status: "In progress"
}];
var award = {
	title: "Gold medal in chess",
	when: "2025",
	detail: "Secured at the college level."
};
var languages = [
	"English",
	"Hindi",
	"Telugu"
];
var hobbies = [
	"Reading books",
	"Playing cricket",
	"Watching movies"
];
var facts = [
	{
		label: "B.Tech, CSE",
		value: "68%",
		meta: "ISBM University · 2025"
	},
	{
		label: "Class XII",
		value: "516",
		meta: "Sri Chaitanya · 2021"
	},
	{
		label: "Class X",
		value: "8.7",
		meta: "CGPA · Ekashila · 2019"
	},
	{
		label: "Chess",
		value: "Gold",
		meta: "College level · 2025"
	}
];
function inLens(lenses, lens) {
	return lens === "all" || lenses.includes(lens);
}
var nav = [
	{
		id: "about",
		label: "About"
	},
	{
		id: "skills",
		label: "Skills"
	},
	{
		id: "work",
		label: "Work"
	},
	{
		id: "path",
		label: "Path"
	},
	{
		id: "contact",
		label: "Contact"
	}
];
var roles = [
	"Java backend",
	"Full stack",
	"Frontend-leaning",
	"Internship",
	"Something else"
];
function Header() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [active, setActive] = (0, import_react.useState)("about");
	(0, import_react.useEffect)(() => {
		const nodes = nav.map((item) => document.getElementById(item.id)).filter((node) => node !== null);
		const observer = new IntersectionObserver((entries) => {
			const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
			if (visible?.target.id) setActive(visible.target.id);
		}, {
			rootMargin: "-30% 0px -55% 0px",
			threshold: [
				.05,
				.2,
				.5
			]
		});
		nodes.forEach((node) => observer.observe(node));
		return () => observer.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-30 border-b border-line bg-paper/95 backdrop-blur-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "#top",
					className: "flex min-h-11 items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-11 place-items-center bg-forest font-display text-sm text-on-forest",
						children: "AN"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-lg leading-none",
						children: "Abhinav Nunna"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-1 lg:flex",
					"aria-label": "Sections",
					children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `#${item.id}`,
						className: `inline-flex min-h-11 items-center px-3 text-sm ${active === item.id ? "text-forest" : "text-muted hover:text-ink"}`,
						"aria-current": active === item.id ? "true" : void 0,
						children: item.label
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#contact",
					className: "hidden min-h-11 items-center bg-forest px-4 text-sm font-medium text-on-forest hover:bg-forest-deep lg:inline-flex",
					children: "Get in touch"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "inline-flex size-11 items-center justify-center border border-line lg:hidden",
					"aria-expanded": open,
					"aria-controls": "mobile-nav",
					onClick: () => setOpen((value) => !value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: open ? "Close menu" : "Open menu"
					}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })]
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			id: "mobile-nav",
			className: "border-t border-line px-4 py-2 lg:hidden",
			"aria-label": "Sections",
			children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: `#${item.id}`,
				className: "flex min-h-11 items-center text-base",
				onClick: () => setOpen(false),
				children: item.label
			}, item.id))
		}) : null]
	});
}
var btn = "inline-flex min-h-11 items-center justify-center gap-2 rounded-md px-4 text-sm font-medium transition-colors duration-200";
var btnSolid = `${btn} bg-forest text-on-forest hover:bg-forest-deep`;
var btnLine = `${btn} border border-line bg-card text-ink hover:border-forest`;
var field = "w-full rounded-md border border-line bg-card px-3 py-3 text-base text-ink placeholder:text-muted";
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "top",
		className: "mx-auto max-w-6xl px-4 pt-10 sm:px-6 sm:pt-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid items-center gap-10 lg:grid-cols-12 lg:gap-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-widest text-forest",
						children: profile.availability
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-4 font-display text-5xl leading-none text-balance text-ink sm:text-7xl",
						children: [profile.first, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block",
							children: profile.last
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-xl font-display text-2xl text-balance text-forest sm:text-3xl",
						children: profile.role
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-xl text-pretty text-lg leading-relaxed text-muted",
						children: profile.summary
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: btnSolid,
								href: `mailto:${profile.email}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Email me"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: btnLine,
								href: profile.resume,
								download: true,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Résumé"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: btnLine,
								href: profile.github,
								target: "_blank",
								rel: "noreferrer",
								children: ["GitHub", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
									className: "size-4",
									"aria-hidden": "true"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: btnLine,
								href: profile.linkedin,
								target: "_blank",
								rel: "noreferrer",
								children: ["LinkedIn", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
									className: "size-4",
									"aria-hidden": "true"
								})]
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
				className: "lg:col-span-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: profile.portrait,
					alt: "Portrait of Abhinav Nunna in a navy suit and glasses",
					width: 960,
					height: 960,
					className: "aspect-square w-full object-cover object-top"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
					className: "flex items-center justify-between bg-forest px-4 py-3 text-sm text-on-forest",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: profile.place }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: profile.region })]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
			className: "mt-12 grid gap-px bg-line sm:grid-cols-2 lg:mt-16 lg:grid-cols-4",
			children: facts.map((fact) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-paper px-4 py-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs font-medium uppercase tracking-widest text-muted",
						children: fact.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-2 font-display text-4xl tabular-nums text-ink",
						children: fact.value
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 text-sm text-muted",
						children: fact.meta
					})
				]
			}, fact.label))
		})]
	});
}
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "about",
		className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-10 lg:grid-cols-12 lg:gap-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-widest text-forest",
					children: "01 — About"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl text-balance sm:text-5xl",
					children: "A Java developer who wants the work to hold up."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-5 text-pretty text-lg leading-relaxed text-muted lg:col-span-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "I’m based in Mahabubabad, Telangana. The degree is computer science from ISBM University. The work I can already do sits on the Java side of the stack: Spring, Hibernate, REST, and MySQL, with HTML, CSS, and JavaScript in front of it." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "React is new. I say so on the résumé and I say so here. MegaBazar is where I’m learning to connect a Spring API to a real interface, without pretending the frontend is already my strongest suit." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "I’m looking for a junior or fresher seat — backend or full stack — where the code gets reviewed and the problems are real." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-6 border-t border-line pt-6 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xs font-medium uppercase tracking-widest text-forest",
							children: "Languages"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 flex flex-wrap gap-2",
							children: languages.map((language) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border border-line bg-card px-3 py-2 text-sm text-ink",
								children: language
							}, language))
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xs font-medium uppercase tracking-widest text-forest",
							children: "Off the clock"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 flex flex-wrap gap-2",
							children: hobbies.map((hobby) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border border-line bg-card px-3 py-2 text-sm text-ink",
								children: hobby
							}, hobby))
						})] })]
					})
				]
			})]
		})
	});
}
function Skills({ lens, onLens }) {
	const hint = lenses.find((item) => item.id === lens)?.hint;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "skills",
		className: "border-t border-line bg-card",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-8 lg:grid-cols-12 lg:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:col-span-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-widest text-forest",
							children: "02 — Skills"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-4xl text-balance sm:text-5xl",
							children: "Read the stack the way a hiring manager would."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-pretty text-lg leading-relaxed text-muted lg:col-span-7",
						children: "Pick a lens. Matching groups stay marked. Nothing is hidden — a fresher profile is more useful when the edges stay visible."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap",
					role: "radiogroup",
					"aria-label": "Hiring lens",
					children: lenses.map((item) => {
						const selected = item.id === lens;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "radio",
							"aria-checked": selected,
							onClick: () => onLens(item.id),
							className: `min-h-11 px-4 text-sm font-medium ${selected ? "bg-forest text-on-forest" : "border border-line bg-paper text-ink hover:border-forest"}`,
							children: item.label
						}, item.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					"aria-live": "polite",
					children: hint
				}),
				lens === "frontend" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-2xl border border-line bg-wash px-4 py-3 text-sm leading-relaxed text-ink",
					children: "Frontend is the growing edge, not the lead. React stays labelled beginner until the work earns a stronger word."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-10 lg:grid-cols-2",
					children: skillGroups.map((group) => {
						const match = inLens(group.lenses, lens);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `border-l-2 pl-5 ${match ? "border-l-forest" : "border-l-line"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl",
									children: group.label
								}), lens !== "all" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs uppercase tracking-widest text-muted",
									children: match ? "In focus" : "Supporting"
								}) : null]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 flex flex-wrap gap-2",
								children: group.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: `border px-3 py-2 text-sm ${match ? "border-forest bg-wash text-ink" : "border-line bg-paper text-muted"}`,
									children: [item.name, item.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-2 text-xs uppercase tracking-widest text-forest",
										children: item.note
									}) : null]
								}, item.name))
							})]
						}, group.id);
					})
				})
			]
		})
	});
}
var courses = [
	{
		code: "CSE-201",
		title: "Java & Spring",
		seats: 40
	},
	{
		code: "CSE-210",
		title: "DBMS",
		seats: 36
	},
	{
		code: "CSE-140",
		title: "Data Structures",
		seats: 42
	},
	{
		code: "CSE-110",
		title: "Web Basics",
		seats: 30
	}
];
var seed = [
	{
		id: "s1",
		name: "Meera K.",
		course: "Java & Spring",
		present: true
	},
	{
		id: "s2",
		name: "Arjun P.",
		course: "DBMS",
		present: false
	},
	{
		id: "s3",
		name: "Lalitha R.",
		course: "Data Structures",
		present: true
	},
	{
		id: "s4",
		name: "Sai V.",
		course: "Java & Spring",
		present: true
	},
	{
		id: "s5",
		name: "Niharika D.",
		course: "Web Basics",
		present: false
	}
];
var tabs = [
	{
		id: "students",
		label: "Students"
	},
	{
		id: "courses",
		label: "Courses"
	},
	{
		id: "attendance",
		label: "Attendance"
	}
];
function JobPortalDemo() {
	const [tab, setTab] = (0, import_react.useState)("students");
	const [students, setStudents] = (0, import_react.useState)(seed);
	const [query, setQuery] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [course, setCourse] = (0, import_react.useState)(courses[0].title);
	const [error, setError] = (0, import_react.useState)("");
	const visible = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		if (!needle) return students;
		return students.filter((student) => student.name.toLowerCase().includes(needle) || student.course.toLowerCase().includes(needle));
	}, [query, students]);
	const present = students.filter((student) => student.present).length;
	function addStudent() {
		const next = name.trim();
		if (next.length < 2) {
			setError("Add a student name before saving.");
			return;
		}
		setError("");
		setStudents((current) => [{
			id: `s${Date.now()}`,
			name: next,
			course,
			present: true
		}, ...current]);
		setName("");
	}
	function toggle(id) {
		setStudents((current) => current.map((student) => student.id === id ? {
			...student,
			present: !student.present
		} : student));
	}
	function remove(id) {
		setStudents((current) => current.filter((student) => student.id !== id));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
			className: "grid grid-cols-3 gap-px bg-line",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-paper px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs uppercase tracking-widest text-muted",
						children: "Records"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-display text-3xl tabular-nums",
						children: students.length
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-paper px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs uppercase tracking-widest text-muted",
						children: "Present"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-display text-3xl tabular-nums",
						children: present
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-paper px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs uppercase tracking-widest text-muted",
						children: "Courses"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-display text-3xl tabular-nums",
						children: courses.length
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "tablist",
				"aria-label": "Job portal views",
				className: "flex flex-wrap gap-2",
				children: tabs.map((item) => {
					const selected = tab === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						role: "tab",
						"aria-selected": selected,
						onClick: () => setTab(item.id),
						className: `min-h-11 px-3 text-sm font-medium ${selected ? "bg-forest text-on-forest" : "border border-line bg-paper text-ink"}`,
						children: item.label
					}, item.id);
				})
			}), tab !== "courses" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: `${field} sm:max-w-xs`,
				value: query,
				onChange: (event) => setQuery(event.target.value),
				placeholder: "Search name or course",
				"aria-label": "Search records"
			}) : null]
		}),
		tab === "students" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-3 border border-line bg-paper p-4 sm:grid-cols-[1fr_1fr_auto]",
					onSubmit: (event) => {
						event.preventDefault();
						addStudent();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm font-medium",
							children: ["Student", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: `${field} mt-2`,
								value: name,
								onChange: (event) => setName(event.target.value),
								placeholder: "Full name"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm font-medium",
							children: ["Course", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: `${field} mt-2`,
								value: course,
								onChange: (event) => setCourse(event.target.value),
								children: courses.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item.title }, item.code))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "min-h-11 self-end bg-forest px-4 text-sm font-medium text-on-forest hover:bg-forest-deep",
							children: "Add record"
						})
					]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm font-medium text-ink",
					role: "alert",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 divide-y divide-line border border-line",
					children: visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "bg-paper px-4 py-6 text-sm text-muted",
						children: "No matching students."
					}) : visible.map((student) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-col gap-3 bg-paper px-4 py-3 sm:flex-row sm:items-center sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium text-ink",
							children: student.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: student.course
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => toggle(student.id),
								className: `min-h-11 px-3 text-sm ${student.present ? "bg-wash text-forest" : "border border-line text-muted"}`,
								children: student.present ? "Present" : "Absent"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => remove(student.id),
								className: "min-h-11 border border-line px-3 text-sm text-ink hover:border-forest",
								children: "Remove"
							})]
						})]
					}, student.id))
				})
			]
		}) : null,
		tab === "courses" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 grid gap-3 sm:grid-cols-2",
			children: courses.map((item) => {
				const enrolled = students.filter((student) => student.course === item.title).length;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "border border-line bg-paper p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-widest text-forest",
							children: item.code
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "mt-2 font-display text-2xl",
							children: item.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums text-ink",
									children: enrolled
								}),
								" enrolled ·",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums",
									children: item.seats
								}),
								" seats"
							]
						})
					]
				}, item.code);
			})
		}) : null,
		tab === "attendance" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 divide-y divide-line border border-line",
			children: visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "bg-paper px-4 py-6 text-sm text-muted",
				children: "No matching records."
			}) : visible.map((student) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-col gap-3 bg-paper px-4 py-3 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: student.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: student.course
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => toggle(student.id),
					className: `min-h-11 px-4 text-sm font-medium ${student.present ? "bg-forest text-on-forest" : "border border-line bg-card text-ink"}`,
					children: student.present ? "Marked present" : "Mark present"
				})]
			}, student.id))
		}) : null
	] });
}
var products = [
	{
		id: "mug",
		name: "Stoneware mug",
		price: 420,
		tag: "Home",
		tone: "wash"
	},
	{
		id: "shirt",
		name: "Cotton shirt",
		price: 1290,
		tag: "Apparel",
		tone: "forest"
	},
	{
		id: "notes",
		name: "Ruled notebook",
		price: 180,
		tag: "Study",
		tone: "paper"
	},
	{
		id: "lamp",
		name: "Brass lamp",
		price: 2140,
		tag: "Home",
		tone: "wash"
	},
	{
		id: "chess",
		name: "Campus chess set",
		price: 980,
		tag: "Play",
		tone: "forest"
	},
	{
		id: "java",
		name: "Core Java notes",
		price: 350,
		tag: "Study",
		tone: "paper"
	}
];
var tags = [
	"All",
	"Home",
	"Apparel",
	"Study",
	"Play"
];
var toneClass = {
	wash: "bg-wash text-forest",
	forest: "bg-forest text-on-forest",
	paper: "bg-paper-deep text-ink"
};
function rupees(value) {
	return new Intl.NumberFormat("en-IN", {
		style: "currency",
		currency: "INR",
		maximumFractionDigits: 0
	}).format(value);
}
function MegaBazarDemo() {
	const [tag, setTag] = (0, import_react.useState)("All");
	const [cart, setCart] = (0, import_react.useState)({});
	const [shopper, setShopper] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [order, setOrder] = (0, import_react.useState)("");
	const catalogue = products.filter((product) => tag === "All" || product.tag === tag);
	const lines = (0, import_react.useMemo)(() => products.filter((product) => (cart[product.id] ?? 0) > 0).map((product) => ({
		product,
		qty: cart[product.id]
	})), [cart]);
	const total = lines.reduce((sum, line) => sum + line.product.price * line.qty, 0);
	const count = lines.reduce((sum, line) => sum + line.qty, 0);
	function setQty(id, qty) {
		setOrder("");
		setCart((current) => {
			const next = { ...current };
			if (qty <= 0) delete next[id];
			else next[id] = qty;
			return next;
		});
	}
	function placeOrder() {
		const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
		if (lines.length === 0) {
			setError("Add something to the cart first.");
			return;
		}
		if (shopper.trim().length < 2 || !emailOk) {
			setError("Checkout needs a name and a real email. This stays in the tab.");
			return;
		}
		setError("");
		setOrder(`MB-${String(Date.now()).slice(-6)}`);
		setCart({});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "lg:col-span-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				role: "tablist",
				"aria-label": "Catalogue",
				children: tags.map((item) => {
					const selected = tag === item;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						role: "tab",
						"aria-selected": selected,
						onClick: () => setTag(item),
						className: `min-h-11 px-3 text-sm ${selected ? "bg-forest text-on-forest" : "border border-line bg-paper text-ink"}`,
						children: item
					}, item);
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 grid gap-3 sm:grid-cols-2",
				children: catalogue.map((product) => {
					const qty = cart[product.id] ?? 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border border-line bg-paper",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `flex aspect-video items-end p-4 ${toneClass[product.tone]}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-3xl",
								children: product.tag
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-medium text-ink",
									children: product.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "tabular-nums text-sm text-forest",
									children: rupees(product.price)
								})]
							}), qty === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setQty(product.id, 1),
								className: "mt-3 min-h-11 w-full border border-line text-sm font-medium hover:border-forest",
								children: "Add to cart"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex items-center justify-between border border-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "inline-flex size-11 items-center justify-center",
										"aria-label": `Remove one ${product.name}`,
										onClick: () => setQty(product.id, qty - 1),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums text-sm",
										children: qty
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "inline-flex size-11 items-center justify-center",
										"aria-label": `Add another ${product.name}`,
										onClick: () => setQty(product.id, qty + 1),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
									})
								]
							})]
						})]
					}, product.id);
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "border border-line bg-paper p-4 lg:col-span-2 lg:p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs uppercase tracking-widest text-forest",
					children: ["Cart · ", count]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "mt-2 font-display text-2xl",
					children: "Checkout sketch"
				}),
				order ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 border border-line bg-wash px-3 py-3 text-sm leading-relaxed text-ink",
					children: [
						"Order ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: order
						}),
						" placed for ",
						shopper.trim(),
						". In the real app this would hit a Spring endpoint. Here it only proves the flow."
					]
				}) : null,
				lines.length === 0 && !order ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm leading-relaxed text-muted",
					children: "The cart is empty. Add a product — registration is only required to place the order."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-3",
					children: lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [line.product.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: [" × ", line.qty]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: rupees(line.product.price * line.qty)
						})]
					}, line.product.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 flex items-baseline justify-between border-t border-line pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted",
						children: "Total"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-3xl tabular-nums",
						children: rupees(total)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-4 space-y-3",
					onSubmit: (event) => {
						event.preventDefault();
						placeOrder();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: ["Shopper name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: `${field} mt-2`,
								value: shopper,
								autoComplete: "name",
								onChange: (event) => setShopper(event.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: `${field} mt-2`,
								type: "email",
								inputMode: "email",
								autoComplete: "email",
								value: email,
								onChange: (event) => setEmail(event.target.value)
							})]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							role: "alert",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "min-h-11 w-full bg-forest text-sm font-medium text-on-forest hover:bg-forest-deep",
							children: "Place order"
						})
					]
				})
			]
		})]
	});
}
function Work({ lens }) {
	const [sketch, setSketch] = (0, import_react.useState)("portal");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "work",
		className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-widest text-forest",
						children: "03 — Work"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl text-balance sm:text-5xl",
						children: "Two builds, both still in motion."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-pretty text-lg leading-relaxed text-muted",
						children: "Academic projects, not production traffic. The cards are the real stack. The sketches below are browser-only, so you can click the flows without a Java server."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-6 lg:grid-cols-2",
				children: projects.map((project) => {
					const match = inLens(project.lenses, lens);
					const active = sketch === project.sketch;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: `flex flex-col border bg-card p-6 sm:p-8 ${match ? "border-forest" : "border-line"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-4xl text-forest",
									children: project.index
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col items-end gap-2 text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "border border-line px-2 py-1 text-xs uppercase tracking-widest text-muted",
										children: project.status
									}), lens !== "all" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs uppercase tracking-widest text-forest",
										children: match ? "In this lens" : "Supporting"
									}) : null]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-6 font-display text-3xl text-balance",
								children: project.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: project.aka
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "mt-5 flex flex-col gap-2 sm:flex-row sm:flex-wrap sm:items-center",
								children: project.flow.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2 text-sm text-ink",
									children: [index > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted",
										"aria-hidden": "true",
										children: "→"
									}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "bg-wash px-2 py-1 text-forest",
										children: step
									})]
								}, step))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 flex flex-wrap gap-2",
								children: project.stack.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "border border-line px-2 py-1 text-xs font-medium uppercase tracking-widest text-muted",
									children: item
								}, item))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-pretty leading-relaxed text-ink",
								children: project.summary
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 space-y-3 text-sm leading-relaxed text-muted",
								children: project.points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "border-t border-line pt-3",
									children: point
								}, point))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-auto pt-6 text-sm text-forest",
								children: project.note
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setSketch(project.sketch);
									const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
									document.getElementById("sketches")?.scrollIntoView({ behavior: reduce ? "auto" : "smooth" });
								},
								className: `mt-6 min-h-11 px-4 text-sm font-medium ${active ? "bg-forest text-on-forest" : "border border-line text-ink hover:border-forest"}`,
								children: active ? "Sketch open below" : "Try this sketch"
							})
						]
					}, project.name);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				id: "sketches",
				className: "mt-10 border border-line bg-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4 border-b border-line p-5 sm:flex-row sm:items-end sm:justify-between sm:p-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-widest text-forest",
							children: "Live sketch"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 font-display text-3xl text-balance",
							children: sketch === "portal" ? "Online Job Portal" : "MegaBazar"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xl text-sm leading-relaxed text-muted",
							children: sketch === "portal" ? "Students, courses, and attendance. Add a record, search, and mark who is present." : "Catalogue, cart, and a checkout that asks for a name before the order is placed."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						role: "tablist",
						"aria-label": "Project sketch",
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "tab",
							"aria-selected": sketch === "portal",
							onClick: () => setSketch("portal"),
							className: `min-h-11 px-3 text-sm font-medium ${sketch === "portal" ? "bg-forest text-on-forest" : "border border-line bg-paper"}`,
							children: "Job portal"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "tab",
							"aria-selected": sketch === "bazaar",
							onClick: () => setSketch("bazaar"),
							className: `min-h-11 px-3 text-sm font-medium ${sketch === "bazaar" ? "bg-forest text-on-forest" : "border border-line bg-paper"}`,
							children: "MegaBazar"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-4 sm:p-8",
					children: sketch === "portal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JobPortalDemo, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MegaBazarDemo, {})
				})]
			})
		]
	});
}
function Path() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "path",
		className: "border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-2xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-widest text-forest",
					children: "04 — Path"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl text-balance sm:text-5xl",
					children: "School, a degree, and the courses still open."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 grid gap-12 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "lg:col-span-7",
					children: education.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: `grid gap-2 border-t border-line py-6 sm:grid-cols-[5rem_1fr] sm:gap-6 ${index === education.length - 1 ? "border-b" : ""}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl tabular-nums text-forest",
							children: item.years
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-medium text-ink",
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-muted",
								children: item.place
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-ink",
								children: item.detail
							})
						] })]
					}, item.title))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-6 lg:col-span-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-forest p-6 text-on-forest sm:p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid size-10 grid-cols-2",
								"aria-hidden": "true",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "bg-on-forest" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "bg-forest-deep" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "bg-forest-deep" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "bg-on-forest" })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-6 text-xs font-medium uppercase tracking-widest text-on-forest",
								children: ["Award · ", award.when]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-2 font-display text-3xl text-balance",
								children: award.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 leading-relaxed",
								children: award.detail
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border border-line bg-card p-6 sm:p-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xs font-medium uppercase tracking-widest text-forest",
							children: "Courses"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-5",
							children: courses$1.map((course) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "border-t border-line pt-4 first:border-t-0 first:pt-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-medium text-ink",
										children: course.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-muted",
										children: course.place
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs uppercase tracking-widest text-forest",
										children: course.status
									})
								]
							}, course.title))
						})]
					})]
				})]
			})]
		})
	});
}
var empty = {
	name: "",
	email: "",
	role: roles[0],
	message: ""
};
function buildLetter(form) {
	return [
		`Hello Abhinav,`,
		``,
		form.message.trim(),
		``,
		`— ${form.name.trim()}`,
		form.email.trim(),
		`Looking at: ${form.role}`
	].join("\n");
}
function Contact() {
	const [form, setForm] = (0, import_react.useState)(empty);
	const [error, setError] = (0, import_react.useState)("");
	const [letter, setLetter] = (0, import_react.useState)("");
	const [copied, setCopied] = (0, import_react.useState)(null);
	async function copy(value, which) {
		try {
			await navigator.clipboard.writeText(value);
			setCopied(which);
			window.setTimeout(() => setCopied((current) => current === which ? null : current), 1600);
		} catch {
			setCopied(null);
			setError("Copy didn’t work in this browser. Select the text instead.");
		}
	}
	function onSubmit(event) {
		event.preventDefault();
		const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim());
		if (!form.name.trim() || !emailOk || form.message.trim().length < 8) {
			setLetter("");
			setError("Add your name, a real email, and a short message (at least a sentence).");
			return;
		}
		setError("");
		setLetter(buildLetter(form));
	}
	const mailto = letter ? `mailto:${profile.email}?subject=${encodeURIComponent(`${form.role} — note from ${form.name.trim()}`)}&body=${encodeURIComponent(letter)}` : `mailto:${profile.email}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "contact",
		className: "border-t border-line bg-card",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-12 px-4 py-16 sm:px-6 sm:py-24 lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-widest text-forest",
						children: "05 — Contact"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl text-balance sm:text-5xl",
						children: "Write if you’re hiring a junior Java developer."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-pretty text-lg leading-relaxed text-muted",
						children: "The form drafts a note you can copy or open in your mail app. Nothing is stored on a server."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-8 space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: "flex min-h-11 items-center gap-3 text-ink hover:text-forest",
								href: `mailto:${profile.email}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
									className: "size-4 text-forest",
									"aria-hidden": "true"
								}), profile.email]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: "flex min-h-11 items-center gap-3 text-ink hover:text-forest",
								href: `tel:${profile.phoneTel}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
									className: "size-4 text-forest",
									"aria-hidden": "true"
								}), profile.phoneDisplay]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex min-h-11 items-center gap-3 text-ink",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
										className: "size-4 text-forest",
										"aria-hidden": "true"
									}),
									profile.place,
									", ",
									profile.region
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: btnLine,
							onClick: () => copy(profile.email, "email"),
							children: [copied === "email" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), copied === "email" ? "Email copied" : "Copy email"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: btnLine,
							onClick: () => copy(profile.phoneTel, "phone"),
							children: [copied === "phone" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), copied === "phone" ? "Number copied" : "Copy number"]
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "space-y-4 border border-line bg-paper p-5 sm:p-8 lg:col-span-7",
				noValidate: true,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: ["Your name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: `${field} mt-2`,
								name: "name",
								autoComplete: "name",
								value: form.name,
								onChange: (event) => setForm({
									...form,
									name: event.target.value
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: ["Your email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: `${field} mt-2`,
								name: "email",
								type: "email",
								autoComplete: "email",
								inputMode: "email",
								value: form.email,
								onChange: (event) => setForm({
									...form,
									email: event.target.value
								})
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-medium",
						children: ["What you’re hiring for", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: `${field} mt-2`,
							name: "role",
							value: form.role,
							onChange: (event) => setForm({
								...form,
								role: event.target.value
							}),
							children: roles.map((role) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: role }, role))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-medium",
						children: ["Message", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: `${field} mt-2 min-h-36 resize-y`,
							name: "message",
							rows: 5,
							value: form.message,
							onChange: (event) => setForm({
								...form,
								message: event.target.value
							}),
							placeholder: "A role, a team, or what you want built."
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-ink",
						role: "alert",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: btnSolid,
						children: "Draft the note"
					}),
					letter ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border border-line bg-card p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium uppercase tracking-widest text-forest",
								children: "Ready to send"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 whitespace-pre-wrap font-sans text-sm leading-relaxed text-ink",
								children: letter
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-col gap-3 sm:flex-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									className: btnSolid,
									href: mailto,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
										className: "size-4",
										"aria-hidden": "true"
									}), "Open email"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: btnLine,
									onClick: () => copy(letter, "letter"),
									children: [copied === "letter" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), copied === "letter" ? "Copied" : "Copy note"]
								})]
							})
						]
					}) : null
				]
			})]
		})
	});
}
function Home() {
	const [lens, setLens] = (0, import_react.useState)("all");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: "#about",
			className: "sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:bg-forest focus:px-4 focus:py-3 focus:text-on-forest",
			children: "Skip to about"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(About, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skills, {
				lens,
				onLens: setLens
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Work, { lens }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Path, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contact, {})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
			className: "border-t border-line px-4 py-8 sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-col gap-3 pb-16 text-sm text-muted sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["© 2026 ", profile.name] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex flex-wrap gap-x-4 gap-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "min-h-11 inline-flex items-center hover:text-ink",
						href: profile.github,
						target: "_blank",
						rel: "noreferrer",
						children: ["github.com/", profile.githubHandle]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "min-h-11 inline-flex items-center hover:text-ink",
						href: profile.linkedin,
						target: "_blank",
						rel: "noreferrer",
						children: "LinkedIn"
					})]
				})]
			})
		})
	] });
}
//#endregion
export { Home as component };
