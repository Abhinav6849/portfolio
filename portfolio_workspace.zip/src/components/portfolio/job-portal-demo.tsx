import { useMemo, useState } from "react";
import { field } from "@/components/portfolio/classes";

type Student = {
  id: string;
  name: string;
  course: string;
  present: boolean;
};

const courses = [
  { code: "CSE-201", title: "Java & Spring", seats: 40 },
  { code: "CSE-210", title: "DBMS", seats: 36 },
  { code: "CSE-140", title: "Data Structures", seats: 42 },
  { code: "CSE-110", title: "Web Basics", seats: 30 },
];

const seed: Student[] = [
  { id: "s1", name: "Meera K.", course: "Java & Spring", present: true },
  { id: "s2", name: "Arjun P.", course: "DBMS", present: false },
  { id: "s3", name: "Lalitha R.", course: "Data Structures", present: true },
  { id: "s4", name: "Sai V.", course: "Java & Spring", present: true },
  { id: "s5", name: "Niharika D.", course: "Web Basics", present: false },
];

const tabs = [
  { id: "students", label: "Students" },
  { id: "courses", label: "Courses" },
  { id: "attendance", label: "Attendance" },
] as const;

type Tab = (typeof tabs)[number]["id"];

export function JobPortalDemo() {
  const [tab, setTab] = useState<Tab>("students");
  const [students, setStudents] = useState<Student[]>(seed);
  const [query, setQuery] = useState("");
  const [name, setName] = useState("");
  const [course, setCourse] = useState(courses[0].title);
  const [error, setError] = useState("");

  const visible = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return students;
    return students.filter(
      (student) =>
        student.name.toLowerCase().includes(needle) ||
        student.course.toLowerCase().includes(needle),
    );
  }, [query, students]);

  const present = students.filter((student) => student.present).length;

  function addStudent() {
    const next = name.trim();
    if (next.length < 2) {
      setError("Add a student name before saving.");
      return;
    }
    setError("");
    setStudents((current) => [
      { id: `s${Date.now()}`, name: next, course, present: true },
      ...current,
    ]);
    setName("");
  }

  function toggle(id: string) {
    setStudents((current) =>
      current.map((student) =>
        student.id === id ? { ...student, present: !student.present } : student,
      ),
    );
  }

  function remove(id: string) {
    setStudents((current) => current.filter((student) => student.id !== id));
  }

  return (
    <div>
      <dl className="grid grid-cols-3 gap-px bg-line">
        <div className="bg-paper px-4 py-3">
          <dt className="text-xs uppercase tracking-widest text-muted">Records</dt>
          <dd className="mt-1 font-display text-3xl tabular-nums">{students.length}</dd>
        </div>
        <div className="bg-paper px-4 py-3">
          <dt className="text-xs uppercase tracking-widest text-muted">Present</dt>
          <dd className="mt-1 font-display text-3xl tabular-nums">{present}</dd>
        </div>
        <div className="bg-paper px-4 py-3">
          <dt className="text-xs uppercase tracking-widest text-muted">Courses</dt>
          <dd className="mt-1 font-display text-3xl tabular-nums">{courses.length}</dd>
        </div>
      </dl>

      <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div role="tablist" aria-label="Job portal views" className="flex flex-wrap gap-2">
          {tabs.map((item) => {
            const selected = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                role="tab"
                aria-selected={selected}
                onClick={() => setTab(item.id)}
                className={`min-h-11 px-3 text-sm font-medium ${
                  selected ? "bg-forest text-on-forest" : "border border-line bg-paper text-ink"
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
        {tab !== "courses" ? (
          <input
            className={`${field} sm:max-w-xs`}
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search name or course"
            aria-label="Search records"
          />
        ) : null}
      </div>

      {tab === "students" ? (
        <div className="mt-4">
          <form
            className="grid gap-3 border border-line bg-paper p-4 sm:grid-cols-[1fr_1fr_auto]"
            onSubmit={(event) => {
              event.preventDefault();
              addStudent();
            }}
          >
            <label className="text-sm font-medium">
              Student
              <input
                className={`${field} mt-2`}
                value={name}
                onChange={(event) => setName(event.target.value)}
                placeholder="Full name"
              />
            </label>
            <label className="text-sm font-medium">
              Course
              <select
                className={`${field} mt-2`}
                value={course}
                onChange={(event) => setCourse(event.target.value)}
              >
                {courses.map((item) => (
                  <option key={item.code}>{item.title}</option>
                ))}
              </select>
            </label>
            <button
              type="submit"
              className="min-h-11 self-end bg-forest px-4 text-sm font-medium text-on-forest hover:bg-forest-deep"
            >
              Add record
            </button>
          </form>
          {error ? (
            <p className="mt-3 text-sm font-medium text-ink" role="alert">
              {error}
            </p>
          ) : null}
          <ul className="mt-4 divide-y divide-line border border-line">
            {visible.length === 0 ? (
              <li className="bg-paper px-4 py-6 text-sm text-muted">No matching students.</li>
            ) : (
              visible.map((student) => (
                <li
                  key={student.id}
                  className="flex flex-col gap-3 bg-paper px-4 py-3 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div>
                    <p className="font-medium text-ink">{student.name}</p>
                    <p className="text-sm text-muted">{student.course}</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => toggle(student.id)}
                      className={`min-h-11 px-3 text-sm ${
                        student.present
                          ? "bg-wash text-forest"
                          : "border border-line text-muted"
                      }`}
                    >
                      {student.present ? "Present" : "Absent"}
                    </button>
                    <button
                      type="button"
                      onClick={() => remove(student.id)}
                      className="min-h-11 border border-line px-3 text-sm text-ink hover:border-forest"
                    >
                      Remove
                    </button>
                  </div>
                </li>
              ))
            )}
          </ul>
        </div>
      ) : null}

      {tab === "courses" ? (
        <ul className="mt-4 grid gap-3 sm:grid-cols-2">
          {courses.map((item) => {
            const enrolled = students.filter((student) => student.course === item.title).length;
            return (
              <li key={item.code} className="border border-line bg-paper p-4">
                <p className="text-xs uppercase tracking-widest text-forest">{item.code}</p>
                <h4 className="mt-2 font-display text-2xl">{item.title}</h4>
                <p className="mt-3 text-sm text-muted">
                  <span className="tabular-nums text-ink">{enrolled}</span> enrolled ·{" "}
                  <span className="tabular-nums">{item.seats}</span> seats
                </p>
              </li>
            );
          })}
        </ul>
      ) : null}

      {tab === "attendance" ? (
        <ul className="mt-4 divide-y divide-line border border-line">
          {visible.length === 0 ? (
            <li className="bg-paper px-4 py-6 text-sm text-muted">No matching records.</li>
          ) : (
            visible.map((student) => (
              <li
                key={student.id}
                className="flex flex-col gap-3 bg-paper px-4 py-3 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <p className="font-medium">{student.name}</p>
                  <p className="text-sm text-muted">{student.course}</p>
                </div>
                <button
                  type="button"
                  onClick={() => toggle(student.id)}
                  className={`min-h-11 px-4 text-sm font-medium ${
                    student.present
                      ? "bg-forest text-on-forest"
                      : "border border-line bg-card text-ink"
                  }`}
                >
                  {student.present ? "Marked present" : "Mark present"}
                </button>
              </li>
            ))
          )}
        </ul>
      ) : null}
    </div>
  );
}
