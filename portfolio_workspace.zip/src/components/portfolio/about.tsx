import { hobbies, languages } from "@/data/profile";

export function About() {
  return (
    <section id="about" className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
      <div className="grid gap-10 lg:grid-cols-12 lg:gap-16">
        <div className="lg:col-span-5">
          <p className="text-xs font-medium uppercase tracking-widest text-forest">01 — About</p>
          <h2 className="mt-3 font-display text-4xl text-balance sm:text-5xl">
            A Java developer who wants the work to hold up.
          </h2>
        </div>
        <div className="space-y-5 text-pretty text-lg leading-relaxed text-muted lg:col-span-7">
          <p>
            I’m based in Mahabubabad, Telangana. The degree is computer science
            from ISBM University. The work I can already do sits on the Java
            side of the stack: Spring, Hibernate, REST, and MySQL, with HTML,
            CSS, and JavaScript in front of it.
          </p>
          <p>
            React is new. I say so on the résumé and I say so here. MegaBazar is
            where I’m learning to connect a Spring API to a real interface,
            without pretending the frontend is already my strongest suit.
          </p>
          <p>
            I’m looking for a junior or fresher seat — backend or full stack —
            where the code gets reviewed and the problems are real.
          </p>
          <div className="grid gap-6 border-t border-line pt-6 sm:grid-cols-2">
            <div>
              <h3 className="text-xs font-medium uppercase tracking-widest text-forest">Languages</h3>
              <ul className="mt-3 flex flex-wrap gap-2">
                {languages.map((language) => (
                  <li key={language} className="border border-line bg-card px-3 py-2 text-sm text-ink">
                    {language}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-xs font-medium uppercase tracking-widest text-forest">Off the clock</h3>
              <ul className="mt-3 flex flex-wrap gap-2">
                {hobbies.map((hobby) => (
                  <li key={hobby} className="border border-line bg-card px-3 py-2 text-sm text-ink">
                    {hobby}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
