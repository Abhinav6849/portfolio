import { ArrowUpRight, Download, Mail } from "lucide-react";
import { facts, profile } from "@/data/profile";
import { btnLine, btnSolid } from "@/components/portfolio/classes";

export function Hero() {
  return (
    <div id="top" className="mx-auto max-w-6xl px-4 pt-10 sm:px-6 sm:pt-16">
      <div className="grid items-center gap-10 lg:grid-cols-12 lg:gap-12">
        <div className="lg:col-span-7">
          <p className="text-xs font-medium uppercase tracking-widest text-forest">
            {profile.availability}
          </p>
          <h1 className="mt-4 font-display text-5xl leading-none text-balance text-ink sm:text-7xl">
            {profile.first}
            <span className="block">{profile.last}</span>
          </h1>
          <p className="mt-5 max-w-xl font-display text-2xl text-balance text-forest sm:text-3xl">
            {profile.role}
          </p>
          <p className="mt-5 max-w-xl text-pretty text-lg leading-relaxed text-muted">
            {profile.summary}
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
            <a className={btnSolid} href={`mailto:${profile.email}`}>
              <Mail className="size-4" aria-hidden="true" />
              Email me
            </a>
            <a className={btnLine} href={profile.resume} download>
              <Download className="size-4" aria-hidden="true" />
              Résumé
            </a>
            <a className={btnLine} href={profile.github} target="_blank" rel="noreferrer">
              GitHub
              <ArrowUpRight className="size-4" aria-hidden="true" />
            </a>
            <a className={btnLine} href={profile.linkedin} target="_blank" rel="noreferrer">
              LinkedIn
              <ArrowUpRight className="size-4" aria-hidden="true" />
            </a>
          </div>
        </div>

        <figure className="lg:col-span-5">
          <img
            src={profile.portrait}
            alt="Portrait of Abhinav Nunna in a navy suit and glasses"
            width={960}
            height={960}
            className="aspect-square w-full object-cover object-top"
          />
          <figcaption className="flex items-center justify-between bg-forest px-4 py-3 text-sm text-on-forest">
            <span>{profile.place}</span>
            <span>{profile.region}</span>
          </figcaption>
        </figure>
      </div>

      <dl className="mt-12 grid gap-px bg-line sm:grid-cols-2 lg:mt-16 lg:grid-cols-4">
        {facts.map((fact) => (
          <div key={fact.label} className="bg-paper px-4 py-5">
            <dt className="text-xs font-medium uppercase tracking-widest text-muted">{fact.label}</dt>
            <dd className="mt-2 font-display text-4xl tabular-nums text-ink">{fact.value}</dd>
            <dd className="mt-1 text-sm text-muted">{fact.meta}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}
