import { inLens, lenses, skillGroups, type Lens } from "@/data/profile";

type Props = {
  lens: Lens;
  onLens: (lens: Lens) => void;
};

export function Skills({ lens, onLens }: Props) {
  const hint = lenses.find((item) => item.id === lens)?.hint;

  return (
    <section id="skills" className="border-t border-line bg-card">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
        <div className="grid gap-8 lg:grid-cols-12 lg:items-end">
          <div className="lg:col-span-5">
            <p className="text-xs font-medium uppercase tracking-widest text-forest">02 — Skills</p>
            <h2 className="mt-3 font-display text-4xl text-balance sm:text-5xl">
              Read the stack the way a hiring manager would.
            </h2>
          </div>
          <p className="text-pretty text-lg leading-relaxed text-muted lg:col-span-7">
            Pick a lens. Matching groups stay marked. Nothing is hidden — a fresher
            profile is more useful when the edges stay visible.
          </p>
        </div>

        <div
          className="mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap"
          role="radiogroup"
          aria-label="Hiring lens"
        >
          {lenses.map((item) => {
            const selected = item.id === lens;
            return (
              <button
                key={item.id}
                type="button"
                role="radio"
                aria-checked={selected}
                onClick={() => onLens(item.id)}
                className={`min-h-11 px-4 text-sm font-medium ${
                  selected
                    ? "bg-forest text-on-forest"
                    : "border border-line bg-paper text-ink hover:border-forest"
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
        <p className="mt-3 text-sm text-muted" aria-live="polite">
          {hint}
        </p>

        {lens === "frontend" ? (
          <p className="mt-6 max-w-2xl border border-line bg-wash px-4 py-3 text-sm leading-relaxed text-ink">
            Frontend is the growing edge, not the lead. React stays labelled
            beginner until the work earns a stronger word.
          </p>
        ) : null}

        <div className="mt-10 grid gap-10 lg:grid-cols-2">
          {skillGroups.map((group) => {
            const match = inLens(group.lenses, lens);
            return (
              <div
                key={group.id}
                className={`border-l-2 pl-5 ${match ? "border-l-forest" : "border-l-line"}`}
              >
                <div className="flex items-baseline justify-between gap-3">
                  <h3 className="font-display text-2xl">{group.label}</h3>
                  {lens !== "all" ? (
                    <span className="text-xs uppercase tracking-widest text-muted">
                      {match ? "In focus" : "Supporting"}
                    </span>
                  ) : null}
                </div>
                <ul className="mt-4 flex flex-wrap gap-2">
                  {group.items.map((item) => (
                    <li
                      key={item.name}
                      className={`border px-3 py-2 text-sm ${
                        match ? "border-forest bg-wash text-ink" : "border-line bg-paper text-muted"
                      }`}
                    >
                      {item.name}
                      {item.note ? (
                        <span className="ml-2 text-xs uppercase tracking-widest text-forest">
                          {item.note}
                        </span>
                      ) : null}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
