import { useMemo, useState } from "react";
import { Minus, Plus } from "lucide-react";
import { field } from "@/components/portfolio/classes";

type Product = {
  id: string;
  name: string;
  price: number;
  tag: string;
  tone: "wash" | "forest" | "paper";
};

const products: Product[] = [
  { id: "mug", name: "Stoneware mug", price: 420, tag: "Home", tone: "wash" },
  { id: "shirt", name: "Cotton shirt", price: 1290, tag: "Apparel", tone: "forest" },
  { id: "notes", name: "Ruled notebook", price: 180, tag: "Study", tone: "paper" },
  { id: "lamp", name: "Brass lamp", price: 2140, tag: "Home", tone: "wash" },
  { id: "chess", name: "Campus chess set", price: 980, tag: "Play", tone: "forest" },
  { id: "java", name: "Core Java notes", price: 350, tag: "Study", tone: "paper" },
];

const tags = ["All", "Home", "Apparel", "Study", "Play"];

const toneClass: Record<Product["tone"], string> = {
  wash: "bg-wash text-forest",
  forest: "bg-forest text-on-forest",
  paper: "bg-paper-deep text-ink",
};

function rupees(value: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value);
}

export function MegaBazarDemo() {
  const [tag, setTag] = useState("All");
  const [cart, setCart] = useState<Record<string, number>>({});
  const [shopper, setShopper] = useState("");
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [order, setOrder] = useState("");

  const catalogue = products.filter((product) => tag === "All" || product.tag === tag);
  const lines = useMemo(
    () =>
      products
        .filter((product) => (cart[product.id] ?? 0) > 0)
        .map((product) => ({ product, qty: cart[product.id] })),
    [cart],
  );
  const total = lines.reduce((sum, line) => sum + line.product.price * line.qty, 0);
  const count = lines.reduce((sum, line) => sum + line.qty, 0);

  function setQty(id: string, qty: number) {
    setOrder("");
    setCart((current) => {
      const next = { ...current };
      if (qty <= 0) delete next[id];
      else next[id] = qty;
      return next;
    });
  }

  function placeOrder() {
    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
    if (lines.length === 0) {
      setError("Add something to the cart first.");
      return;
    }
    if (shopper.trim().length < 2 || !emailOk) {
      setError("Checkout needs a name and a real email. This stays in the tab.");
      return;
    }
    setError("");
    setOrder(`MB-${String(Date.now()).slice(-6)}`);
    setCart({});
  }

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <div className="lg:col-span-3">
        <div className="flex flex-wrap gap-2" role="tablist" aria-label="Catalogue">
          {tags.map((item) => {
            const selected = tag === item;
            return (
              <button
                key={item}
                type="button"
                role="tab"
                aria-selected={selected}
                onClick={() => setTag(item)}
                className={`min-h-11 px-3 text-sm ${
                  selected ? "bg-forest text-on-forest" : "border border-line bg-paper text-ink"
                }`}
              >
                {item}
              </button>
            );
          })}
        </div>
        <ul className="mt-4 grid gap-3 sm:grid-cols-2">
          {catalogue.map((product) => {
            const qty = cart[product.id] ?? 0;
            return (
              <li key={product.id} className="border border-line bg-paper">
                <div className={`flex aspect-video items-end p-4 ${toneClass[product.tone]}`}>
                  <span className="font-display text-3xl">{product.tag}</span>
                </div>
                <div className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <h4 className="font-medium text-ink">{product.name}</h4>
                    <p className="tabular-nums text-sm text-forest">{rupees(product.price)}</p>
                  </div>
                  {qty === 0 ? (
                    <button
                      type="button"
                      onClick={() => setQty(product.id, 1)}
                      className="mt-3 min-h-11 w-full border border-line text-sm font-medium hover:border-forest"
                    >
                      Add to cart
                    </button>
                  ) : (
                    <div className="mt-3 flex items-center justify-between border border-line">
                      <button
                        type="button"
                        className="inline-flex size-11 items-center justify-center"
                        aria-label={`Remove one ${product.name}`}
                        onClick={() => setQty(product.id, qty - 1)}
                      >
                        <Minus className="size-4" />
                      </button>
                      <span className="tabular-nums text-sm">{qty}</span>
                      <button
                        type="button"
                        className="inline-flex size-11 items-center justify-center"
                        aria-label={`Add another ${product.name}`}
                        onClick={() => setQty(product.id, qty + 1)}
                      >
                        <Plus className="size-4" />
                      </button>
                    </div>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      </div>

      <aside className="border border-line bg-paper p-4 lg:col-span-2 lg:p-5">
        <p className="text-xs uppercase tracking-widest text-forest">Cart · {count}</p>
        <h4 className="mt-2 font-display text-2xl">Checkout sketch</h4>
        {order ? (
          <p className="mt-4 border border-line bg-wash px-3 py-3 text-sm leading-relaxed text-ink">
            Order <span className="font-medium">{order}</span> placed for {shopper.trim()}. In the
            real app this would hit a Spring endpoint. Here it only proves the flow.
          </p>
        ) : null}
        {lines.length === 0 && !order ? (
          <p className="mt-4 text-sm leading-relaxed text-muted">
            The cart is empty. Add a product — registration is only required to place the order.
          </p>
        ) : (
          <ul className="mt-4 space-y-3">
            {lines.map((line) => (
              <li key={line.product.id} className="flex items-center justify-between gap-3 text-sm">
                <span>
                  {line.product.name}
                  <span className="text-muted"> × {line.qty}</span>
                </span>
                <span className="tabular-nums">{rupees(line.product.price * line.qty)}</span>
              </li>
            ))}
          </ul>
        )}
        <p className="mt-4 flex items-baseline justify-between border-t border-line pt-4">
          <span className="text-sm text-muted">Total</span>
          <span className="font-display text-3xl tabular-nums">{rupees(total)}</span>
        </p>
        <form
          className="mt-4 space-y-3"
          onSubmit={(event) => {
            event.preventDefault();
            placeOrder();
          }}
        >
          <label className="block text-sm font-medium">
            Shopper name
            <input
              className={`${field} mt-2`}
              value={shopper}
              autoComplete="name"
              onChange={(event) => setShopper(event.target.value)}
            />
          </label>
          <label className="block text-sm font-medium">
            Email
            <input
              className={`${field} mt-2`}
              type="email"
              inputMode="email"
              autoComplete="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
            />
          </label>
          {error ? (
            <p className="text-sm font-medium" role="alert">
              {error}
            </p>
          ) : null}
          <button
            type="submit"
            className="min-h-11 w-full bg-forest text-sm font-medium text-on-forest hover:bg-forest-deep"
          >
            Place order
          </button>
        </form>
      </aside>
    </div>
  );
}
