export const btn =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-md px-4 text-sm font-medium transition-colors duration-200";

export const btnSolid = `${btn} bg-forest text-on-forest hover:bg-forest-deep`;

export const btnLine = `${btn} border border-line bg-card text-ink hover:border-forest`;

export const field =
  "w-full rounded-md border border-line bg-card px-3 py-3 text-base text-ink placeholder:text-muted";
