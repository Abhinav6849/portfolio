import { award, courses, education } from "@/data/profile";

export function Path() {
  return (
    <section id="path" className="border-t border-line">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
        <div className="max-w-2xl">
          <p className="text-xs font-medium uppercase tracking-widest text-forest">04 — Path</p>
          <h2 className="mt-3 font-display text-4xl text-balance sm:text-5xl">
            School, a degree, and the courses still open.
          </h2>
        </div>

        <div className="mt-12 grid gap-12 lg:grid-cols-12">
          <ol className="lg:col-span-7">
            {education.map((item, index) => (
              <li
                key={item.title}
                className={`grid gap-2 border-t border-line py-6 sm:grid-cols-[5rem_1fr] sm:gap-6 ${
                  index === education.length - 1 ? "border-b" : ""
                }`}
              >
                <p className="font-display text-2xl tabular-nums text-forest">{item.years}</p>
                <div>
                  <h3 className="text-lg font-medium text-ink">{item.title}</h3>
                  <p className="mt-1 text-muted">{item.place}</p>
                  <p className="mt-1 text-sm text-ink">{item.detail}</p>
                </div>
              </li>
            ))}
          </ol>

          <div className="flex flex-col gap-6 lg:col-span-5">
            <div className="bg-forest p-6 text-on-forest sm:p-8">
              <div className="grid size-10 grid-cols-2" aria-hidden="true">
                <span className="bg-on-forest" />
                <span className="bg-forest-deep" />
                <span className="bg-forest-deep" />
                <span className="bg-on-forest" />
              </div>
              <p className="mt-6 text-xs font-medium uppercase tracking-widest text-on-forest">Award · {award.when}</p>
              <h3 className="mt-2 font-display text-3xl text-balance">{award.title}</h3>
              <p className="mt-3 leading-relaxed">{award.detail}</p>
            </div>

            <div className="border border-line bg-card p-6 sm:p-8">
              <h3 className="text-xs font-medium uppercase tracking-widest text-forest">Courses</h3>
              <ul className="mt-4 space-y-5">
                {courses.map((course) => (
                  <li key={course.title} className="border-t border-line pt-4 first:border-t-0 first:pt-0">
                    <p className="font-medium text-ink">{course.title}</p>
                    <p className="mt-1 text-sm text-muted">{course.place}</p>
                    <p className="mt-2 text-xs uppercase tracking-widest text-forest">{course.status}</p>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
