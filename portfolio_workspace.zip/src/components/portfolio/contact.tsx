import { useState, type FormEvent } from "react";
import { Check, Copy, Mail, MapPin, Phone } from "lucide-react";
import { profile, roles } from "@/data/profile";
import { btnLine, btnSolid, field } from "@/components/portfolio/classes";

type FormState = {
  name: string;
  email: string;
  role: string;
  message: string;
};

const empty: FormState = {
  name: "",
  email: "",
  role: roles[0],
  message: "",
};

function buildLetter(form: FormState) {
  return [
    `Hello Abhinav,`,
    ``,
    form.message.trim(),
    ``,
    `— ${form.name.trim()}`,
    form.email.trim(),
    `Looking at: ${form.role}`,
  ].join("\n");
}

export function Contact() {
  const [form, setForm] = useState<FormState>(empty);
  const [error, setError] = useState("");
  const [letter, setLetter] = useState("");
  const [copied, setCopied] = useState<"email" | "phone" | "letter" | null>(null);

  async function copy(value: string, which: "email" | "phone" | "letter") {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(which);
      window.setTimeout(() => setCopied((current) => (current === which ? null : current)), 1600);
    } catch {
      setCopied(null);
      setError("Copy didn’t work in this browser. Select the text instead.");
    }
  }

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim());
    if (!form.name.trim() || !emailOk || form.message.trim().length < 8) {
      setLetter("");
      setError("Add your name, a real email, and a short message (at least a sentence).");
      return;
    }
    setError("");
    setLetter(buildLetter(form));
  }

  const mailto = letter
    ? `mailto:${profile.email}?subject=${encodeURIComponent(
        `${form.role} — note from ${form.name.trim()}`,
      )}&body=${encodeURIComponent(letter)}`
    : `mailto:${profile.email}`;

  return (
    <section id="contact" className="border-t border-line bg-card">
      <div className="mx-auto grid max-w-6xl gap-12 px-4 py-16 sm:px-6 sm:py-24 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <p className="text-xs font-medium uppercase tracking-widest text-forest">05 — Contact</p>
          <h2 className="mt-3 font-display text-4xl text-balance sm:text-5xl">
            Write if you’re hiring a junior Java developer.
          </h2>
          <p className="mt-4 text-pretty text-lg leading-relaxed text-muted">
            The form drafts a note you can copy or open in your mail app. Nothing
            is stored on a server.
          </p>

          <ul className="mt-8 space-y-3">
            <li>
              <a className="flex min-h-11 items-center gap-3 text-ink hover:text-forest" href={`mailto:${profile.email}`}>
                <Mail className="size-4 text-forest" aria-hidden="true" />
                {profile.email}
              </a>
            </li>
            <li>
              <a className="flex min-h-11 items-center gap-3 text-ink hover:text-forest" href={`tel:${profile.phoneTel}`}>
                <Phone className="size-4 text-forest" aria-hidden="true" />
                {profile.phoneDisplay}
              </a>
            </li>
            <li className="flex min-h-11 items-center gap-3 text-ink">
              <MapPin className="size-4 text-forest" aria-hidden="true" />
              {profile.place}, {profile.region}
            </li>
          </ul>

          <div className="mt-4 flex flex-wrap gap-3">
            <button type="button" className={btnLine} onClick={() => copy(profile.email, "email")}>
              {copied === "email" ? <Check className="size-4" /> : <Copy className="size-4" />}
              {copied === "email" ? "Email copied" : "Copy email"}
            </button>
            <button type="button" className={btnLine} onClick={() => copy(profile.phoneTel, "phone")}>
              {copied === "phone" ? <Check className="size-4" /> : <Copy className="size-4" />}
              {copied === "phone" ? "Number copied" : "Copy number"}
            </button>
          </div>
        </div>

        <form onSubmit={onSubmit} className="space-y-4 border border-line bg-paper p-5 sm:p-8 lg:col-span-7" noValidate>
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="block text-sm font-medium">
              Your name
              <input
                className={`${field} mt-2`}
                name="name"
                autoComplete="name"
                value={form.name}
                onChange={(event) => setForm({ ...form, name: event.target.value })}
              />
            </label>
            <label className="block text-sm font-medium">
              Your email
              <input
                className={`${field} mt-2`}
                name="email"
                type="email"
                autoComplete="email"
                inputMode="email"
                value={form.email}
                onChange={(event) => setForm({ ...form, email: event.target.value })}
              />
            </label>
          </div>
          <label className="block text-sm font-medium">
            What you’re hiring for
            <select
              className={`${field} mt-2`}
              name="role"
              value={form.role}
              onChange={(event) => setForm({ ...form, role: event.target.value })}
            >
              {roles.map((role) => (
                <option key={role}>{role}</option>
              ))}
            </select>
          </label>
          <label className="block text-sm font-medium">
            Message
            <textarea
              className={`${field} mt-2 min-h-36 resize-y`}
              name="message"
              rows={5}
              value={form.message}
              onChange={(event) => setForm({ ...form, message: event.target.value })}
              placeholder="A role, a team, or what you want built."
            />
          </label>

          {error ? (
            <p className="text-sm font-medium text-ink" role="alert">
              {error}
            </p>
          ) : null}

          <button type="submit" className={btnSolid}>
            Draft the note
          </button>

          {letter ? (
            <div className="border border-line bg-card p-4">
              <p className="text-xs font-medium uppercase tracking-widest text-forest">Ready to send</p>
              <pre className="mt-3 whitespace-pre-wrap font-sans text-sm leading-relaxed text-ink">{letter}</pre>
              <div className="mt-4 flex flex-col gap-3 sm:flex-row">
                <a className={btnSolid} href={mailto}>
                  <Mail className="size-4" aria-hidden="true" />
                  Open email
                </a>
                <button type="button" className={btnLine} onClick={() => copy(letter, "letter")}>
                  {copied === "letter" ? <Check className="size-4" /> : <Copy className="size-4" />}
                  {copied === "letter" ? "Copied" : "Copy note"}
                </button>
              </div>
            </div>
          ) : null}
        </form>
      </div>
    </section>
  );
}
