import { useState } from "react";
import { inLens, projects, type Lens } from "@/data/profile";
import { JobPortalDemo } from "@/components/portfolio/job-portal-demo";
import { MegaBazarDemo } from "@/components/portfolio/megabazar-demo";

export function Work({ lens }: { lens: Lens }) {
  const [sketch, setSketch] = useState<"portal" | "bazaar">("portal");

  return (
    <section id="work" className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
      <div className="max-w-2xl">
        <p className="text-xs font-medium uppercase tracking-widest text-forest">03 — Work</p>
        <h2 className="mt-3 font-display text-4xl text-balance sm:text-5xl">
          Two builds, both still in motion.
        </h2>
        <p className="mt-4 text-pretty text-lg leading-relaxed text-muted">
          Academic projects, not production traffic. The cards are the real stack.
          The sketches below are browser-only, so you can click the flows without
          a Java server.
        </p>
      </div>

      <div className="mt-12 grid gap-6 lg:grid-cols-2">
        {projects.map((project) => {
          const match = inLens(project.lenses, lens);
          const active = sketch === project.sketch;
          return (
            <article
              key={project.name}
              className={`flex flex-col border bg-card p-6 sm:p-8 ${
                match ? "border-forest" : "border-line"
              }`}
            >
              <div className="flex items-start justify-between gap-4">
                <p className="font-display text-4xl text-forest">{project.index}</p>
                <div className="flex flex-col items-end gap-2 text-right">
                  <span className="border border-line px-2 py-1 text-xs uppercase tracking-widest text-muted">
                    {project.status}
                  </span>
                  {lens !== "all" ? (
                    <span className="text-xs uppercase tracking-widest text-forest">
                      {match ? "In this lens" : "Supporting"}
                    </span>
                  ) : null}
                </div>
              </div>
              <h3 className="mt-6 font-display text-3xl text-balance">{project.name}</h3>
              <p className="mt-1 text-sm text-muted">{project.aka}</p>
              <ol className="mt-5 flex flex-col gap-2 sm:flex-row sm:flex-wrap sm:items-center">
                {project.flow.map((step, index) => (
                  <li key={step} className="flex items-center gap-2 text-sm text-ink">
                    {index > 0 ? <span className="text-muted" aria-hidden="true">→</span> : null}
                    <span className="bg-wash px-2 py-1 text-forest">{step}</span>
                  </li>
                ))}
              </ol>
              <ul className="mt-4 flex flex-wrap gap-2">
                {project.stack.map((item) => (
                  <li key={item} className="border border-line px-2 py-1 text-xs font-medium uppercase tracking-widest text-muted">
                    {item}
                  </li>
                ))}
              </ul>
              <p className="mt-5 text-pretty leading-relaxed text-ink">{project.summary}</p>
              <ul className="mt-4 space-y-3 text-sm leading-relaxed text-muted">
                {project.points.map((point) => (
                  <li key={point} className="border-t border-line pt-3">
                    {point}
                  </li>
                ))}
              </ul>
              <p className="mt-auto pt-6 text-sm text-forest">{project.note}</p>
              <button
                type="button"
                onClick={() => {
                  setSketch(project.sketch);
                  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
                  document.getElementById("sketches")?.scrollIntoView({
                    behavior: reduce ? "auto" : "smooth",
                  });
                }}
                className={`mt-6 min-h-11 px-4 text-sm font-medium ${
                  active ? "bg-forest text-on-forest" : "border border-line text-ink hover:border-forest"
                }`}
              >
                {active ? "Sketch open below" : "Try this sketch"}
              </button>
            </article>
          );
        })}
      </div>

      <div id="sketches" className="mt-10 border border-line bg-card">
        <div className="flex flex-col gap-4 border-b border-line p-5 sm:flex-row sm:items-end sm:justify-between sm:p-8">
          <div>
            <p className="text-xs font-medium uppercase tracking-widest text-forest">Live sketch</p>
            <h3 className="mt-2 font-display text-3xl text-balance">
              {sketch === "portal" ? "Online Job Portal" : "MegaBazar"}
            </h3>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted">
              {sketch === "portal"
                ? "Students, courses, and attendance. Add a record, search, and mark who is present."
                : "Catalogue, cart, and a checkout that asks for a name before the order is placed."}
            </p>
          </div>
          <div role="tablist" aria-label="Project sketch" className="flex gap-2">
            <button
              type="button"
              role="tab"
              aria-selected={sketch === "portal"}
              onClick={() => setSketch("portal")}
              className={`min-h-11 px-3 text-sm font-medium ${
                sketch === "portal" ? "bg-forest text-on-forest" : "border border-line bg-paper"
              }`}
            >
              Job portal
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={sketch === "bazaar"}
              onClick={() => setSketch("bazaar")}
              className={`min-h-11 px-3 text-sm font-medium ${
                sketch === "bazaar" ? "bg-forest text-on-forest" : "border border-line bg-paper"
              }`}
            >
              MegaBazar
            </button>
          </div>
        </div>
        <div className="p-4 sm:p-8">
          {sketch === "portal" ? <JobPortalDemo /> : <MegaBazarDemo />}
        </div>
      </div>
    </section>
  );
}
