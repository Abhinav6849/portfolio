export type Lens = "all" | "backend" | "fullstack" | "frontend";
export type Focus = Exclude<Lens, "all">;

export const profile = {
  name: "Abhinav Nunna",
  first: "Abhinav",
  last: "Nunna",
  role: "Java Full Stack Developer",
  availability: "Fresher · open to roles",
  place: "Uyyalawada, Mahabubabad",
  region: "Telangana 506381",
  email: "abhinavnunna0907@gmail.com",
  phoneDisplay: "+91 91103 22065",
  phoneTel: "+919110322065",
  github: "https://github.com/Abhinav6849",
  githubHandle: "Abhinav6849",
  linkedin: "https://www.linkedin.com/in/nunna-abhinav-8572463a8",
  resume: "/Abhinav-Nunna-CV.pdf",
  portrait: "/portrait.jpg",
  summary:
    "Aspiring Java full-stack developer with a solid grounding in Core Java, Spring Boot, and modern web work. I like reliable, scalable applications — and I want to grow by solving real problems with a team.",
};

export const lenses: { id: Lens; label: string; hint: string }[] = [
  { id: "all", label: "Whole profile", hint: "Everything on the résumé, unfiltered." },
  { id: "backend", label: "Backend", hint: "Java, Spring, Hibernate, and data stores." },
  { id: "fullstack", label: "Full stack", hint: "An API plus a screen someone can use." },
  { id: "frontend", label: "Frontend", hint: "HTML, CSS, JavaScript — React is still early." },
];

export type SkillGroup = {
  id: string;
  label: string;
  lenses: Focus[];
  items: { name: string; note?: string }[];
};

export const skillGroups: SkillGroup[] = [
  {
    id: "backend",
    label: "Backend",
    lenses: ["backend", "fullstack"],
    items: [
      { name: "Core Java" },
      { name: "J2EE" },
      { name: "Spring Framework" },
      { name: "Spring Boot" },
      { name: "Hibernate" },
      { name: "RESTful services" },
    ],
  },
  {
    id: "frontend",
    label: "Frontend",
    lenses: ["frontend", "fullstack"],
    items: [
      { name: "HTML5" },
      { name: "CSS3" },
      { name: "JavaScript" },
      { name: "Bootstrap" },
      { name: "React", note: "Beginner" },
    ],
  },
  {
    id: "data",
    label: "Databases",
    lenses: ["backend", "fullstack", "frontend"],
    items: [{ name: "MySQL" }, { name: "PostgreSQL" }],
  },
  {
    id: "tools",
    label: "Tools",
    lenses: ["backend", "fullstack", "frontend"],
    items: [
      { name: "Git" },
      { name: "GitHub" },
      { name: "Maven" },
      { name: "Eclipse" },
      { name: "IntelliJ IDEA" },
      { name: "Postman" },
    ],
  },
  {
    id: "concepts",
    label: "Core concepts",
    lenses: ["backend", "fullstack", "frontend"],
    items: [
      { name: "Object-oriented programming" },
      { name: "Data structures & algorithms" },
      { name: "MVC" },
      { name: "Software development life cycle" },
    ],
  },
];

export type Project = {
  index: string;
  name: string;
  aka: string;
  status: string;
  sketch: "portal" | "bazaar";
  lenses: Focus[];
  stack: string[];
  flow: string[];
  summary: string;
  points: string[];
  note: string;
};

export const projects: Project[] = [
  {
    index: "01",
    name: "Online Job Portal",
    aka: "Records, courses, attendance",
    status: "In progress",
    sketch: "portal",
    lenses: ["backend", "fullstack"],
    stack: ["Java", "Spring Boot", "MySQL", "HTML", "CSS"],
    flow: ["HTML & CSS", "Spring Boot REST", "MySQL"],
    summary:
      "A Spring Boot application for managing student records, course details, and attendance. The useful core is a REST API with full create, read, update, and delete.",
    points: [
      "Designed the web flow for records a college admin actually keeps: students, courses, attendance.",
      "REST endpoints cover the full CRUD cycle so data operations stay straightforward.",
      "MySQL holds the data, with queries tuned so the system stays responsive.",
    ],
    note: "Sits beside the Spring Boot & Microservices certification, also in progress.",
  },
  {
    index: "02",
    name: "MegaBazar",
    aka: "E-commerce web application",
    status: "In progress",
    sketch: "bazaar",
    lenses: ["backend", "fullstack", "frontend"],
    stack: ["Java", "Spring", "Hibernate", "React", "MySQL"],
    flow: ["React", "Spring + Hibernate", "MySQL"],
    summary:
      "An end-to-end shop: registration, login, a product catalogue, a cart, and order placement. Spring and Hibernate serve the API; React renders the store.",
    points: [
      "Secure registration and login before a shopper can move through the store.",
      "Catalogue, cart, and orders share one backend instead of living as separate prototypes.",
      "React components call the Spring APIs. The Java side is where I’m strongest — React is marked beginner on purpose.",
    ],
    note: "The project I use to practice connecting a real UI to a Java API.",
  },
];

export const education = [
  {
    years: "2025",
    title: "Bachelor of Technology — Computer Science & Engineering",
    place: "ISBM University",
    detail: "Aggregate 68%",
  },
  {
    years: "2021",
    title: "Intermediate (Class XII)",
    place: "Sri Chaitanya College",
    detail: "Score 516",
  },
  {
    years: "2019",
    title: "Secondary School Certificate (Class X)",
    place: "Ekashila E Techno School",
    detail: "CGPA 8.7",
  },
];

export const courses = [
  {
    title: "Java Full Stack Development",
    place: "360 DigiRI",
    status: "In progress",
  },
  {
    title: "Spring Boot & Microservices",
    place: "Online Job Portal project certification",
    status: "In progress",
  },
];

export const award = {
  title: "Gold medal in chess",
  when: "2025",
  detail: "Secured at the college level.",
};

export const languages = ["English", "Hindi", "Telugu"];

export const hobbies = ["Reading books", "Playing cricket", "Watching movies"];

export const facts = [
  { label: "B.Tech, CSE", value: "68%", meta: "ISBM University · 2025" },
  { label: "Class XII", value: "516", meta: "Sri Chaitanya · 2021" },
  { label: "Class X", value: "8.7", meta: "CGPA · Ekashila · 2019" },
  { label: "Chess", value: "Gold", meta: "College level · 2025" },
];

export function inLens(lenses: Focus[], lens: Lens) {
  return lens === "all" || lenses.includes(lens);
}

export const nav = [
  { id: "about", label: "About" },
  { id: "skills", label: "Skills" },
  { id: "work", label: "Work" },
  { id: "path", label: "Path" },
  { id: "contact", label: "Contact" },
];

export const roles = [
  "Java backend",
  "Full stack",
  "Frontend-leaning",
  "Internship",
  "Something else",
];
