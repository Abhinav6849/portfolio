import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import type { Lens } from "@/data/profile";
import { profile } from "@/data/profile";
import { Header } from "@/components/portfolio/header";
import { Hero } from "@/components/portfolio/hero";
import { About } from "@/components/portfolio/about";
import { Skills } from "@/components/portfolio/skills";
import { Work } from "@/components/portfolio/work";
import { Path } from "@/components/portfolio/path";
import { Contact } from "@/components/portfolio/contact";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [lens, setLens] = useState<Lens>("all");

  return (
    <>
      <a
        href="#about"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:bg-forest focus:px-4 focus:py-3 focus:text-on-forest"
      >
        Skip to about
      </a>
      <Header />
      <main>
        <Hero />
        <About />
        <Skills lens={lens} onLens={setLens} />
        <Work lens={lens} />
        <Path />
        <Contact />
      </main>
      <footer className="border-t border-line px-4 py-8 sm:px-6">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 pb-16 text-sm text-muted sm:flex-row sm:items-center sm:justify-between">
          <p>© 2026 {profile.name}</p>
          <p className="flex flex-wrap gap-x-4 gap-y-2">
            <a className="min-h-11 inline-flex items-center hover:text-ink" href={profile.github} target="_blank" rel="noreferrer">
              github.com/{profile.githubHandle}
            </a>
            <a className="min-h-11 inline-flex items-center hover:text-ink" href={profile.linkedin} target="_blank" rel="noreferrer">
              LinkedIn
            </a>
          </p>
        </div>
      </footer>
    </>
  );
}
